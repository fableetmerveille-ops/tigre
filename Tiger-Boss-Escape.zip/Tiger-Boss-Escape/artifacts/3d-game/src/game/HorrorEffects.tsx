import { useEffect, useRef } from 'react';
import { useGameStore } from './useGameStore';

export default function HorrorEffects() {
  const { heartRate, alertLevel, isHiding, health, gameState, gracePeriod } = useGameStore();
  const beatRef = useRef(0);
  const opRef = useRef(0);

  const inGame = gameState === 'playing' || gameState === 'cage';
  if (!inGame) return null;

  const danger = Math.max(0, Math.min(1, (alertLevel - 20) / 80));
  const hurt = health < 40;
  const grace = gracePeriod > 0;

  const vignetteIntensity = isHiding ? 0.85 : grace ? 0.3 : 0.35 + danger * 0.5;
  const vignetteColor = hurt ? 'rgba(120,0,0,' : isHiding ? 'rgba(0,60,20,' : 'rgba(0,0,0,';

  return (
    <>
      {/* Vignette */}
      <div style={{
        position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 8,
        background: `radial-gradient(ellipse at center, transparent 30%, ${vignetteColor}${vignetteIntensity}) 100%)`,
        transition: 'background 0.8s',
      }}/>

      {/* Heartbeat flash when in danger */}
      {alertLevel > 60 && !isHiding && (
        <HeartbeatFlash bpm={heartRate} alertLevel={alertLevel}/>
      )}

      {/* Low health warning overlay */}
      {hurt && (
        <div style={{
          position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 9,
          background: 'radial-gradient(ellipse at center, transparent 40%, rgba(180,0,0,0.4) 100%)',
          animation: 'pulse 0.7s ease-in-out infinite alternate',
        }}/>
      )}

      {/* Hiding overlay */}
      {isHiding && (
        <div style={{
          position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 9,
          background: 'rgba(0,0,0,0.55)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <div style={{
            color: '#00ff88', fontSize: 18, fontFamily: 'monospace',
            letterSpacing: 4, textShadow: '0 0 10px #00ff88',
            animation: 'pulse 1.5s ease-in-out infinite',
          }}>
            CACHÉ — Appuyez sur E pour sortir
          </div>
        </div>
      )}

      <style>{`
        @keyframes pulse {
          0% { opacity: 0.6; }
          100% { opacity: 1; }
        }
        @keyframes heartbeat {
          0%,100% { opacity: 0; }
          5%,15% { opacity: 0.15; }
          10% { opacity: 0.25; }
        }
      `}</style>
    </>
  );
}

function HeartbeatFlash({ bpm, alertLevel }: { bpm: number; alertLevel: number }) {
  const interval = (60 / bpm) * 1000;
  const intensity = Math.min(0.4, (alertLevel - 60) / 200);
  return (
    <div style={{
      position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 9,
      background: `rgba(200,0,0,${intensity})`,
      animation: `heartbeat ${interval}ms ease-in-out infinite`,
    }}/>
  );
}
