import { create } from 'zustand';
import { GameState, Enemy, EnemyAIState } from './types';

interface GameStore {
  gameState: GameState;
  playerPos: [number, number, number];
  yaw: number;
  pitch: number;
  velocityY: number;
  isGrounded: boolean;
  isCrouching: boolean;
  isSprinting: boolean;
  isHiding: boolean;
  hidingSpotId: string | null;
  nearHidingSpot: string | null;
  health: number;
  stamina: number;
  noiseLevel: number;       // 0-100 current noise emitted
  alertLevel: number;       // 0-100 global alert
  heartRate: number;        // 60-180 BPM based on danger
  gracePeriod: number;
  timeElapsed: number;
  cageTimeElapsed: number;
  cageDoorOpen: boolean;
  currentRoom: string;
  transformationProgress: number;
  enemies: Enemy[];
  stepPhase: number;
  hasKeycard: boolean;

  setGameState: (state: GameState) => void;
  setPlayerPos: (pos: [number, number, number]) => void;
  setYaw: (yaw: number) => void;
  setPitch: (pitch: number) => void;
  setVelocityY: (v: number) => void;
  setGrounded: (g: boolean) => void;
  setCrouching: (c: boolean) => void;
  setSprinting: (s: boolean) => void;
  setHiding: (hiding: boolean, spotId?: string | null) => void;
  setNearHidingSpot: (id: string | null) => void;
  setHealth: (h: number) => void;
  damagePlayer: (amount: number) => void;
  setStamina: (s: number) => void;
  setNoiseLevel: (n: number) => void;
  setAlertLevel: (l: number) => void;
  setHeartRate: (r: number) => void;
  decrementGrace: (delta: number) => void;
  incrementTime: (delta: number) => void;
  incrementCageTime: (delta: number) => void;
  openCageDoor: () => void;
  setCurrentRoom: (room: string) => void;
  setTransformationProgress: (p: number) => void;
  updateEnemy: (id: string, updates: Partial<Enemy>) => void;
  setEnemies: (enemies: Enemy[]) => void;
  setStepPhase: (p: number) => void;
  setHasKeycard: (v: boolean) => void;
  resetGame: () => void;
}

const makeEnemies = (): Enemy[] => [
  { id: 'scientist1', position: [-18, 0, -8], type: 'scientist', speed: 2.8, isAlerted: false, aiState: 'patrol', lastKnownPlayerPos: null, searchTimer: 0, alertLevel: 0 },
  { id: 'scientist2', position: [-10, 0, -18], type: 'scientist', speed: 2.8, isAlerted: false, aiState: 'patrol', lastKnownPlayerPos: null, searchTimer: 0, alertLevel: 0 },
  { id: 'scientist3', position: [18, 0, -22], type: 'scientist', speed: 3.0, isAlerted: false, aiState: 'patrol', lastKnownPlayerPos: null, searchTimer: 0, alertLevel: 0 },
  { id: 'scientist4', position: [0, 0, -22], type: 'scientist', speed: 2.6, isAlerted: false, aiState: 'patrol', lastKnownPlayerPos: null, searchTimer: 0, alertLevel: 0 },
  { id: 'guard1', position: [0, 0, -1], type: 'guard', speed: 4.0, isAlerted: false, aiState: 'patrol', lastKnownPlayerPos: null, searchTimer: 0, alertLevel: 0 },
  { id: 'guard2', position: [20, 0, 20], type: 'guard', speed: 4.2, isAlerted: false, aiState: 'patrol', lastKnownPlayerPos: null, searchTimer: 0, alertLevel: 0 },
  { id: 'employee1', position: [-18, 0, 20], type: 'employee', speed: 2.2, isAlerted: false, aiState: 'patrol', lastKnownPlayerPos: null, searchTimer: 0, alertLevel: 0 },
  { id: 'employee2', position: [8, 0, 18], type: 'employee', speed: 2.0, isAlerted: false, aiState: 'patrol', lastKnownPlayerPos: null, searchTimer: 0, alertLevel: 0 },
];

const INITIAL_STATE = {
  gameState: 'intro' as GameState,
  playerPos: [-15, 0.15, -15] as [number, number, number],
  yaw: 0,
  pitch: 0,
  velocityY: 0,
  isGrounded: true,
  isCrouching: false,
  isSprinting: false,
  isHiding: false,
  hidingSpotId: null,
  nearHidingSpot: null,
  health: 100,
  stamina: 100,
  noiseLevel: 0,
  alertLevel: 0,
  heartRate: 70,
  gracePeriod: 40,
  timeElapsed: 0,
  cageTimeElapsed: 0,
  cageDoorOpen: false,
  currentRoom: 'Cage Labo',
  transformationProgress: 0,
  enemies: makeEnemies(),
  stepPhase: 0,
  hasKeycard: false,
};

export const useGameStore = create<GameStore>((set) => ({
  ...INITIAL_STATE,

  setGameState: (gameState) => set({ gameState }),
  setPlayerPos: (playerPos) => set({ playerPos }),
  setYaw: (yaw) => set({ yaw }),
  setPitch: (pitch) => set({ pitch }),
  setVelocityY: (velocityY) => set({ velocityY }),
  setGrounded: (isGrounded) => set({ isGrounded }),
  setCrouching: (isCrouching) => set({ isCrouching }),
  setSprinting: (isSprinting) => set({ isSprinting }),
  setHiding: (hiding, spotId = null) => set({ isHiding: hiding, hidingSpotId: spotId ?? null }),
  setNearHidingSpot: (nearHidingSpot) => set({ nearHidingSpot }),
  setHealth: (health) => set({ health }),
  damagePlayer: (amount) => set((s) => {
    const health = Math.max(0, s.health - amount);
    return { health, gameState: health <= 0 ? 'caught' : s.gameState };
  }),
  setStamina: (stamina) => set({ stamina: Math.max(0, Math.min(100, stamina)) }),
  setNoiseLevel: (noiseLevel) => set({ noiseLevel: Math.max(0, Math.min(100, noiseLevel)) }),
  setAlertLevel: (alertLevel) => set({ alertLevel: Math.max(0, Math.min(100, alertLevel)) }),
  setHeartRate: (heartRate) => set({ heartRate }),
  decrementGrace: (delta) => set((s) => ({ gracePeriod: Math.max(0, s.gracePeriod - delta) })),
  incrementTime: (delta) => set((s) => ({ timeElapsed: s.timeElapsed + delta })),
  incrementCageTime: (delta) => set((s) => ({ cageTimeElapsed: s.cageTimeElapsed + delta })),
  openCageDoor: () => set({ cageDoorOpen: true }),
  setCurrentRoom: (currentRoom) => set({ currentRoom }),
  setTransformationProgress: (transformationProgress) => set({ transformationProgress }),
  updateEnemy: (id, updates) => set((s) => ({
    enemies: s.enemies.map(e => e.id === id ? { ...e, ...updates } : e),
  })),
  setEnemies: (enemies) => set({ enemies }),
  setStepPhase: (stepPhase) => set({ stepPhase }),
  setHasKeycard: (hasKeycard) => set({ hasKeycard }),
  resetGame: () => set({ ...INITIAL_STATE, enemies: makeEnemies() }),
}));
