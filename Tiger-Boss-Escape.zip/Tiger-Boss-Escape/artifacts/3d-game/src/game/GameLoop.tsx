// GameLoop is a stub - game logic is handled in Player.tsx
export default function GameLoop() {
  return null;
}
