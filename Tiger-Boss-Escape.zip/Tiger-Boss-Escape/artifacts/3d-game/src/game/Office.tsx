import * as THREE from 'three';
import { useGameStore } from './useGameStore';
import { HIDING_SPOTS } from './types';
import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';

const WALL_H = 4;
const W = 57; // building footprint

function Wall({ pos, size, color = '#14142a', emissive }: { pos:[number,number,number]; size:[number,number,number]; color?:string; emissive?:string }) {
  return <mesh position={pos} castShadow receiveShadow>
    <boxGeometry args={size} />
    <meshStandardMaterial color={color} emissive={emissive ?? '#000'} emissiveIntensity={emissive ? 0.3 : 0} roughness={0.92} metalness={0.05} />
  </mesh>;
}

function Floor({ pos, size, color = '#111', rot = 0 }: { pos:[number,number,number]; size:[number,number]; color?:string; rot?:number }) {
  return <mesh position={pos} receiveShadow rotation={[-Math.PI/2, rot, 0]}>
    <planeGeometry args={size} />
    <meshStandardMaterial color={color} roughness={0.95} />
  </mesh>;
}

function Sign({ pos, text, color }: { pos:[number,number,number]; text:string; color:string }) {
  return (
    <mesh position={pos}>
      <boxGeometry args={[2, 0.4, 0.06]} />
      <meshStandardMaterial color="#0a0a12" emissive={color} emissiveIntensity={0.6} />
    </mesh>
  );
}

function FlickerLight({ pos, baseIntensity = 1.2, color = '#fffaee' }: { pos:[number,number,number]; baseIntensity?:number; color?:string }) {
  const lightRef = useRef<THREE.PointLight>(null);
  const offset = useRef(Math.random() * 100);
  useFrame(({ clock }) => {
    if (!lightRef.current) return;
    const t = clock.elapsedTime + offset.current;
    // Slight flicker
    const flicker = 0.9 + 0.1 * Math.sin(t * 17.3) * Math.sin(t * 8.7);
    lightRef.current.intensity = baseIntensity * flicker;
  });
  return <pointLight ref={lightRef} position={pos} color={color} intensity={baseIntensity} distance={14} castShadow />;
}

function Locker({ pos, double = false }: { pos:[number,number,number]; double?:boolean }) {
  const offsets = double ? [0, 0.65] : [0];
  return <group position={pos}>
    {offsets.map((ox, i) => (
      <group key={i} position={[ox, 0, 0]}>
        <mesh castShadow receiveShadow position={[0,0.9,0]}>
          <boxGeometry args={[0.6,1.8,0.42]} />
          <meshStandardMaterial color="#3a3a4a" metalness={0.7} roughness={0.4} />
        </mesh>
        <mesh position={[0,0.9,0.22]}>
          <boxGeometry args={[0.56,1.76,0.02]} />
          <meshStandardMaterial color="#2a2a3a" metalness={0.8} roughness={0.3} />
        </mesh>
        <mesh position={[0.2,0.9,0.24]}>
          <boxGeometry args={[0.04,0.1,0.04]} />
          <meshStandardMaterial color="#aaa" metalness={0.9} roughness={0.1} />
        </mesh>
        {[-0.35,0,0.35].map((y,j)=>(
          <mesh key={j} position={[0,y+0.9,0.22]}>
            <boxGeometry args={[0.38,0.035,0.01]} />
            <meshStandardMaterial color="#111" />
          </mesh>
        ))}
      </group>
    ))}
  </group>;
}

function Desk({ pos, rot=0 }: { pos:[number,number,number]; rot?:number }) {
  return <group position={pos} rotation={[0,rot,0]}>
    <mesh position={[0,0.84,0]} castShadow receiveShadow>
      <boxGeometry args={[1.9,0.07,0.85]} />
      <meshStandardMaterial color="#2e1a08" roughness={0.8} />
    </mesh>
    {[[-0.85,0.4,-0.38],[-0.85,0.4,0.38],[0.85,0.4,-0.38],[0.85,0.4,0.38]].map(([x,y,z],i)=>(
      <mesh key={i} position={[x as number,y as number,z as number]} castShadow>
        <boxGeometry args={[0.06,0.8,0.06]} />
        <meshStandardMaterial color="#1a0e04" />
      </mesh>
    ))}
    <mesh position={[0,1.2,-0.2]}>
      <boxGeometry args={[0.5,0.35,0.06]} />
      <meshStandardMaterial color="#111" />
    </mesh>
    <mesh position={[0,1.2,-0.17]}>
      <boxGeometry args={[0.44,0.29,0.01]} />
      <meshStandardMaterial color="#001133" emissive="#001133" emissiveIntensity={0.8} />
    </mesh>
    <mesh position={[0.5,0.885,0.1]} rotation={[-Math.PI/2,0,0.1]}>
      <planeGeometry args={[0.3,0.4]} />
      <meshStandardMaterial color="#e0d8cc" roughness={1} />
    </mesh>
  </group>;
}

function LabTable({ pos }: { pos:[number,number,number] }) {
  return <group position={pos}>
    <mesh position={[0,0.92,0]} castShadow receiveShadow>
      <boxGeometry args={[2.0,0.06,0.9]} />
      <meshStandardMaterial color="#c8c8c0" metalness={0.5} roughness={0.4} />
    </mesh>
    {[[-0.9,0.46,-0.4],[-0.9,0.46,0.4],[0.9,0.46,-0.4],[0.9,0.46,0.4]].map(([x,y,z],i)=>(
      <mesh key={i} position={[x as number,y as number,z as number]}>
        <boxGeometry args={[0.05,0.92,0.05]} />
        <meshStandardMaterial color="#999" metalness={0.7} roughness={0.3} />
      </mesh>
    ))}
    <mesh position={[-0.6,1.05,0]}>
      <cylinderGeometry args={[0.07,0.06,0.25,8]} />
      <meshStandardMaterial color="#88ddff" transparent opacity={0.6} emissive="#44aaff" emissiveIntensity={0.3} />
    </mesh>
    <mesh position={[-0.3,1.15,0.1]}>
      <cylinderGeometry args={[0.05,0.05,0.45,8]} />
      <meshStandardMaterial color="#ff44aa" transparent opacity={0.55} emissive="#ff0066" emissiveIntensity={0.4} />
    </mesh>
    <mesh position={[0.1,1.05,-0.1]}>
      <cylinderGeometry args={[0.09,0.07,0.3,8]} />
      <meshStandardMaterial color="#aaff44" transparent opacity={0.6} emissive="#66ff00" emissiveIntensity={0.25} />
    </mesh>
    <mesh position={[0.6,1.1,0]}>
      <cylinderGeometry args={[0.06,0.1,0.35,6]} />
      <meshStandardMaterial color="#444" metalness={0.9} roughness={0.2} />
    </mesh>
    <mesh position={[0.6,1.3,0]}>
      <cylinderGeometry args={[0.025,0.025,0.25,6]} />
      <meshStandardMaterial color="#888" metalness={0.8} roughness={0.2} />
    </mesh>
  </group>;
}

function StorageArea() {
  const boxes = useMemo<Array<[number,number,number,number,number,number]>>(() => [
    [-23,0.5,10, 1.2,1.0,1.0],
    [-19,0.5,12, 1.0,1.0,1.0],
    [-23,1.5,10, 1.2,1.0,1.0],
    [-23,0.5,20, 1.0,1.0,1.0],
    [-16,0.5,22, 1.2,0.8,1.0],
    [-12,0.5,11, 1.0,1.0,1.0],
    [-21,0.5,23, 1.0,0.8,1.0],
    [-14,0.5,17, 1.2,1.0,1.0],
    [-24,0.5,16, 1.0,1.2,0.8],
    [-20,1.5,23, 1.0,0.8,1.0],
    [-16,1.5,22, 1.2,0.8,1.0],
    [-10,0.5,14, 0.9,0.9,0.9],
    [-24,0.5,25, 1.1,0.9,1.1],
  ], []);
  const colors = ['#4a3010','#3a2808','#5a3818','#443010','#3d2a0a'];
  return <group>
    {boxes.map(([x,y,z,w,h,d],i)=>(
      <mesh key={i} position={[x,y,z]} castShadow receiveShadow>
        <boxGeometry args={[w,h,d]} />
        <meshStandardMaterial color={colors[i%colors.length]} roughness={0.95} />
      </mesh>
    ))}
    {/* Caution tape */}
    <mesh position={[-18,0.51,16]} rotation={[-Math.PI/2,0.5,0]}>
      <planeGeometry args={[0.12,3.5]} />
      <meshStandardMaterial color="#ffcc00" roughness={1} />
    </mesh>
    {/* Shelves */}
    {[9,12,15].map((z,i)=>(
      <mesh key={i} position={[-27,1.2+i*0.1,z]} castShadow>
        <boxGeometry args={[0.5,0.06,2]} />
        <meshStandardMaterial color="#5a3a18" roughness={0.9} />
      </mesh>
    ))}
  </group>;
}

function Cage() {
  const { cageDoorOpen } = useGameStore();
  const bh = 3;
  const yp = bh / 2;
  const doorGlowRef = useRef<THREE.PointLight>(null);
  useFrame(({ clock }) => {
    if (!doorGlowRef.current || !cageDoorOpen) return;
    doorGlowRef.current.intensity = 3.5 + Math.sin(clock.elapsedTime * 3) * 0.5;
  });

  const bars: React.ReactNode[] = [];
  const count = 20;
  for (let i = 0; i <= count; i++) {
    const t = i / count;
    const bx = -20 + t * 10;
    const bz_n = -20, bz_s = -10;

    bars.push(<mesh key={`n${i}`} position={[bx, yp, bz_n]} castShadow>
      <cylinderGeometry args={[0.04,0.04,bh,6]}/>
      <meshStandardMaterial color="#888" metalness={0.9} roughness={0.15}/>
    </mesh>);

    const isDoor = bx > -15.5 && bx < -10.0;
    if (!isDoor || !cageDoorOpen) {
      bars.push(<mesh key={`s${i}`} position={[bx, yp, bz_s]} castShadow>
        <cylinderGeometry args={[0.04,0.04,bh,6]}/>
        <meshStandardMaterial color={isDoor ? '#cc8822' : '#888'} metalness={0.9} roughness={0.15}/>
      </mesh>);
    }

    const bz = -20 + t * 10;
    bars.push(<mesh key={`w${i}`} position={[-20, yp, bz]} castShadow>
      <cylinderGeometry args={[0.04,0.04,bh,6]}/><meshStandardMaterial color="#888" metalness={0.9} roughness={0.15}/>
    </mesh>);
    bars.push(<mesh key={`e${i}`} position={[-10, yp, bz]} castShadow>
      <cylinderGeometry args={[0.04,0.04,bh,6]}/><meshStandardMaterial color="#888" metalness={0.9} roughness={0.15}/>
    </mesh>);
  }

  return <group>
    {bars}
    {/* Top frame */}
    <mesh position={[-15, bh, -20]}><boxGeometry args={[10.1,0.08,0.12]}/><meshStandardMaterial color="#666" metalness={0.8}/></mesh>
    <mesh position={[-15, bh, -10]}><boxGeometry args={[10.1,0.08,0.12]}/><meshStandardMaterial color="#666" metalness={0.8}/></mesh>
    <mesh position={[-20, bh, -15]}><boxGeometry args={[0.12,0.08,10.1]}/><meshStandardMaterial color="#666" metalness={0.8}/></mesh>
    <mesh position={[-10, bh, -15]}><boxGeometry args={[0.12,0.08,10.1]}/><meshStandardMaterial color="#666" metalness={0.8}/></mesh>

    {/* Floor */}
    <mesh position={[-15,0.004,-15]} rotation={[-Math.PI/2,0,0]}>
      <planeGeometry args={[9.8,9.8]}/>
      <meshStandardMaterial color="#101810" roughness={1}/>
    </mesh>
    {/* Straw */}
    <mesh position={[-15,0.01,-12]} rotation={[-Math.PI/2,0,0]}>
      <planeGeometry args={[8,2]}/>
      <meshStandardMaterial color="#8a7030" roughness={1}/>
    </mesh>
    {/* Water bowl */}
    <group position={[-18,0,-18]}>
      <mesh position={[0,0.12,0]}><cylinderGeometry args={[0.28,0.22,0.22,10]}/><meshStandardMaterial color="#444" metalness={0.6}/></mesh>
      <mesh position={[0,0.21,0]}><cylinderGeometry args={[0.24,0.24,0.04,10]}/><meshStandardMaterial color="#2244bb" transparent opacity={0.75}/></mesh>
    </group>
    {/* Food bowl */}
    <group position={[-12,0,-18]}>
      <mesh position={[0,0.1,0]}><cylinderGeometry args={[0.22,0.18,0.18,10]}/><meshStandardMaterial color="#555" metalness={0.5}/></mesh>
      <mesh position={[0,0.17,0]}><cylinderGeometry args={[0.18,0.18,0.04,10]}/><meshStandardMaterial color="#884422"/></mesh>
    </group>

    {/* Door opening effects */}
    {cageDoorOpen && <>
      <mesh position={[-12.75, 1.5, -9.97]}>
        <boxGeometry args={[4.5, 3, 0.04]}/>
        <meshStandardMaterial color="#00ff88" emissive="#00ff88" emissiveIntensity={0.5} transparent opacity={0.12}/>
      </mesh>
      <pointLight ref={doorGlowRef} position={[-12.75, 1.5, -9.5]} color="#00ff88" intensity={3.5} distance={10}/>
      {/* Arrow on floor */}
      <mesh position={[-12.75, 0.01, -11.5]} rotation={[-Math.PI/2, Math.PI, 0]}>
        <planeGeometry args={[2,3]}/>
        <meshStandardMaterial color="#00ff88" emissive="#00ff88" emissiveIntensity={0.8} transparent opacity={0.75}/>
      </mesh>
    </>}
    {/* Cage label */}
    <mesh position={[-15, 3.2, -9.9]}>
      <boxGeometry args={[3,0.4,0.05]}/>
      <meshStandardMaterial color="#001a00" emissive="#00aa44" emissiveIntensity={0.8}/>
    </mesh>
  </group>;
}

function HidingSpotHighlight() {
  const { nearHidingSpot, isHiding } = useGameStore();
  if (!nearHidingSpot) return null;
  const spot = HIDING_SPOTS.find(s => s.id === nearHidingSpot);
  if (!spot) return null;
  const color = isHiding ? '#00ff88' : '#ffaa00';
  return <mesh position={[spot.position[0], 0.01, spot.position[2]]} rotation={[-Math.PI/2,0,0]}>
    <circleGeometry args={[spot.radius + 0.4, 20]}/>
    <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.6} transparent opacity={0.28}/>
  </mesh>;
}

export default function Office() {
  return <group>
    {/* === FLOORS === */}
    {/* Lab (NW) */}
    <Floor pos={[-16.5,0,-16.5]} size={[23,23]} color="#181f18"/>
    {/* Office (NE) */}
    <Floor pos={[16.5,0,-16.5]} size={[23,23]} color="#16162a"/>
    {/* Hallway (center) */}
    <Floor pos={[0,0,0]} size={[10,10]} color="#121212"/>
    {/* Corridors */}
    <Floor pos={[0,0,-16.5]} size={[10,23]} color="#121418"/>
    <Floor pos={[0,0,16.5]} size={[10,23]} color="#121418"/>
    <Floor pos={[-16.5,0,0]} size={[23,10]} color="#121418"/>
    <Floor pos={[16.5,0,0]} size={[23,10]} color="#121418"/>
    {/* Storage (SW) */}
    <Floor pos={[-16.5,0,16.5]} size={[23,23]} color="#1f1610"/>
    {/* Lobby (SE) */}
    <Floor pos={[16.5,0,16.5]} size={[23,23]} color="#12221a"/>

    {/* === OUTER WALLS === */}
    <Wall pos={[-28.5,WALL_H/2,0]} size={[1,WALL_H,W]}/>
    <Wall pos={[28.5,WALL_H/2,0]} size={[1,WALL_H,W]}/>
    <Wall pos={[0,WALL_H/2,-28.5]} size={[W,WALL_H,1]}/>
    {/* South wall with exit gap */}
    <Wall pos={[-9,WALL_H/2,28.5]} size={[37,WALL_H,1]}/>
    <Wall pos={[24,WALL_H/2,28.5]} size={[9,WALL_H,1]}/>
    {/* Exit gap at x:10.5 to 19.5 — 9 units */}

    {/* === INNER WALLS (must match Player.tsx INNER_WALLS) === */}
    {/* z=-5 horizontal wall, west segment: x -27.5 to -5.5 */}
    <Wall pos={[-16.5,WALL_H/2,-5]} size={[22,WALL_H,1]} color="#101028"/>
    {/* z=-5 horizontal wall, east segment: x 5.5 to 27.5 */}
    <Wall pos={[16.5,WALL_H/2,-5]} size={[22,WALL_H,1]} color="#101028"/>
    {/* z=5 horizontal wall, west segment */}
    <Wall pos={[-16.5,WALL_H/2,5]} size={[22,WALL_H,1]} color="#101028"/>
    {/* z=5 horizontal wall, east segment */}
    <Wall pos={[16.5,WALL_H/2,5]} size={[22,WALL_H,1]} color="#101028"/>
    {/* x=-5 vertical wall, north segment: z -27.5 to -5.5 */}
    <Wall pos={[-5,WALL_H/2,-16.5]} size={[1,WALL_H,22]} color="#101028"/>
    {/* x=5 vertical wall, north segment */}
    <Wall pos={[5,WALL_H/2,-16.5]} size={[1,WALL_H,22]} color="#101028"/>
    {/* x=-5 vertical wall, south segment: z 5.5 to 27.5 */}
    <Wall pos={[-5,WALL_H/2,16.5]} size={[1,WALL_H,22]} color="#101028"/>
    {/* x=5 vertical wall, south segment */}
    <Wall pos={[5,WALL_H/2,16.5]} size={[1,WALL_H,22]} color="#101028"/>

    {/* === CEILING === */}
    <mesh position={[0, WALL_H, 0]} rotation={[Math.PI/2, 0, 0]}>
      <planeGeometry args={[W, W]} />
      <meshStandardMaterial color="#08080e" side={THREE.BackSide} />
    </mesh>

    {/* === CAGE === */}
    <Cage />

    {/* === LAB FURNITURE === */}
    <LabTable pos={[-22,0.92,-22]}/>
    <LabTable pos={[-13,0.92,-22]}/>
    <LabTable pos={[-22,0.92,-12]}/>
    <LabTable pos={[-13,0.92,-12]}/>
    {/* Lab overhead light strip */}
    <mesh position={[-17,3.95,-17]}>
      <boxGeometry args={[6,0.08,0.25]}/>
      <meshStandardMaterial color="#ccc" emissive="#ffffcc" emissiveIntensity={0.9}/>
    </mesh>

    {/* === OFFICE DESKS === */}
    <Desk pos={[12,0,-22]}/>
    <Desk pos={[22,0,-22]}/>
    <Desk pos={[12,0,-12]}/>
    <Desk pos={[22,0,-12]}/>
    <Desk pos={[20,0,-17]} rot={Math.PI/2}/>

    {/* === LOBBY === */}
    <Desk pos={[10,0,20]}/>
    <Desk pos={[22,0,14]}/>
    {/* Reception counter */}
    <mesh position={[12,0.6,14]} castShadow receiveShadow>
      <boxGeometry args={[6,1.2,0.5]}/>
      <meshStandardMaterial color="#1a1a2a" metalness={0.4} roughness={0.6}/>
    </mesh>
    <mesh position={[12,1.21,14]}>
      <boxGeometry args={[6.1,0.06,0.6]}/>
      <meshStandardMaterial color="#c8c8c8" metalness={0.5} roughness={0.4}/>
    </mesh>

    {/* === LOCKERS (hiding spots) === */}
    <Locker pos={[-26,0,-22]} double />
    <Locker pos={[-26,0,-8]} double />
    {/* Extra lockers in office */}
    <Locker pos={[27,0,-22]} double />

    {/* === STORAGE === */}
    <StorageArea/>

    {/* === SIGNS === */}
    {/* Lab sign */}
    <Sign pos={[-5.6,2.5,-16]} text="LABORATOIRE" color="#4488ff"/>
    {/* Office sign */}
    <Sign pos={[5.6,2.5,-16]} text="BUREAUX" color="#aa44ff"/>
    {/* Storage sign */}
    <Sign pos={[-5.6,2.5,16]} text="ENTREPÔT" color="#ff8844"/>
    {/* Lobby sign */}
    <Sign pos={[5.6,2.5,16]} text="HALL / SORTIE" color="#00ff88"/>

    {/* === EXIT === */}
    {/* Exit floor glow */}
    <mesh position={[17,0.01,22]} rotation={[-Math.PI/2,0,0]} receiveShadow>
      <planeGeometry args={[8,5]}/>
      <meshStandardMaterial color="#00ff44" emissive="#00ff44" emissiveIntensity={0.18} transparent opacity={0.4}/>
    </mesh>
    {/* Exit door frame */}
    <mesh position={[15,2,28.5]}><boxGeometry args={[0.4,4,0.4]}/><meshStandardMaterial color="#00aa33" metalness={0.5}/></mesh>
    <mesh position={[20,2,28.5]}><boxGeometry args={[0.4,4,0.4]}/><meshStandardMaterial color="#00aa33" metalness={0.5}/></mesh>
    <mesh position={[17.5,4,28.5]}><boxGeometry args={[5.5,0.4,0.4]}/><meshStandardMaterial color="#00aa33" metalness={0.5}/></mesh>
    {/* EXIT sign */}
    <mesh position={[17,3.6,28.3]}>
      <boxGeometry args={[2.6,0.55,0.1]}/>
      <meshStandardMaterial color="#003300" emissive="#00cc00" emissiveIntensity={1.8}/>
    </mesh>
    <pointLight position={[17,3.5,27]} color="#00ff00" intensity={4} distance={6}/>
    <pointLight position={[17,1.5,22]} color="#00ff44" intensity={6} distance={18} castShadow/>

    {/* === HIDING SPOT HIGHLIGHTS === */}
    <HidingSpotHighlight/>

    {/* === LIGHTING === */}
    <ambientLight intensity={0.06} color="#10101a"/>

    {/* Lab area */}
    <FlickerLight pos={[-22,3.6,-22]} baseIntensity={1.8} color="#44ff88"/>
    <FlickerLight pos={[-10,3.6,-10]} baseIntensity={1.4} color="#5577ff"/>

    {/* Office area */}
    <pointLight position={[17,3.5,-22]} color="#5566ff" intensity={2.2} distance={14} castShadow/>
    <pointLight position={[10,3.5,-14]} color="#4455ee" intensity={1.4} distance={10}/>

    {/* Central hallway */}
    <FlickerLight pos={[0,3.5,0]} baseIntensity={1.5} color="#ffaa44"/>

    {/* Corridors */}
    <pointLight position={[0,3.5,-16]} color="#e0e0ff" intensity={1.2} distance={12}/>
    <pointLight position={[0,3.5,16]} color="#e0e0ff" intensity={1.2} distance={12}/>

    {/* Storage */}
    <pointLight position={[-17,3.5,17]} color="#ff4422" intensity={1.6} distance={14} castShadow/>
    <pointLight position={[-24,3.5,25]} color="#ff3311" intensity={1.0} distance={10}/>

    {/* Lobby */}
    <pointLight position={[17,3.5,17]} color="#44ffcc" intensity={2.2} distance={16} castShadow/>

    {/* Lab beaker glow spots */}
    <pointLight position={[-21,1.1,-22]} color="#44aaff" intensity={0.6} distance={3}/>
    <pointLight position={[-13,1.2,-22]} color="#ff44aa" intensity={0.5} distance={2.5}/>
  </group>;
}
