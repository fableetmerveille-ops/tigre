import { useGameStore } from './useGameStore';
import { HIDING_SPOTS } from './types';

export default function HUD() {
  const {
    gameState, health, stamina, noiseLevel, alertLevel, heartRate,
    gracePeriod, currentRoom, cageTimeElapsed, cageDoorOpen,
    timeElapsed, isHiding, isSprinting, isCrouching, nearHidingSpot,
    enemies,
  } = useGameStore();

  if (gameState !== 'playing' && gameState !== 'cage') return null;

  const isCage = gameState === 'cage';
  const timeLeft = Math.max(0, 45 - cageTimeElapsed);
  const minutes = Math.floor(timeElapsed / 60);
  const seconds = Math.floor(timeElapsed % 60).toString().padStart(2, '0');
  const alertedEnemies = enemies.filter(e => e.aiState === 'chase' || e.aiState === 'search');
  const chasing = enemies.filter(e => e.aiState === 'chase');
  const nearSpot = nearHidingSpot ? HIDING_SPOTS.find(s => s.id === nearHidingSpot) : null;

  return (
    <div style={{ position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 15, fontFamily: 'monospace' }}>

      {/* TOP BAR */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '10px 20px',
        background: 'linear-gradient(to bottom, rgba(0,0,0,0.7), transparent)',
      }}>
        <div style={{ color: '#aaa', fontSize: 11, letterSpacing: 3 }}>
          ◆ NEOCORP INDUSTRIES ◆
        </div>
        <div style={{ color: '#fff', fontSize: 13, letterSpacing: 2 }}>
          {isCage ? '——  ZONE SÉCURISÉE  ——' : `${minutes}:${seconds}  ▸  ${currentRoom}`}
        </div>
        <div style={{ color: alertedEnemies.length > 0 ? '#ff3300' : '#555', fontSize: 11, letterSpacing: 2 }}>
          {alertedEnemies.length > 0 ? `⚠ ALERTE ×${alertedEnemies.length}` : '◉ CALME'}
        </div>
      </div>

      {/* LEFT - BARS */}
      <div style={{
        position: 'absolute', left: 18, top: '50%', transform: 'translateY(-50%)',
        display: 'flex', flexDirection: 'column', gap: 16,
      }}>
        <Bar label="VIE" value={health} max={100} color={health > 60 ? '#44ff88' : health > 30 ? '#ffaa00' : '#ff2200'} icon="♥"/>
        <Bar label="ENDURANCE" value={stamina} max={100} color={isSprinting ? '#ff6600' : '#4488ff'} icon="⚡"/>
        <Bar label="BRUIT" value={noiseLevel} max={100} color={noiseLevel > 60 ? '#ff2200' : noiseLevel > 30 ? '#ffaa00' : '#44ff88'} icon="♪"/>
        {gracePeriod > 0 && gameState === 'playing' && (
          <Bar label="GRÂCE" value={gracePeriod} max={40} color="#8855ff" icon="✦"/>
        )}
      </div>

      {/* RIGHT - STATUS */}
      <div style={{
        position: 'absolute', right: 18, top: '50%', transform: 'translateY(-50%)',
        display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'flex-end',
      }}>
        {/* Heart rate */}
        <div style={{
          background: 'rgba(0,0,0,0.6)', border: '1px solid #333',
          padding: '8px 14px', borderRadius: 6, textAlign: 'right',
        }}>
          <div style={{ color: '#ff4444', fontSize: 10, letterSpacing: 2 }}>BPM</div>
          <div style={{ color: '#ff4444', fontSize: 22, fontWeight: 'bold' }}>{Math.round(heartRate)}</div>
          <HeartECG rate={heartRate}/>
        </div>

        {/* Alert level */}
        {alertLevel > 10 && (
          <div style={{
            background: 'rgba(40,0,0,0.7)', border: '1px solid #ff2200',
            padding: '6px 12px', borderRadius: 6, textAlign: 'right',
          }}>
            <div style={{ color: '#ff4400', fontSize: 10, letterSpacing: 2 }}>NIVEAU D'ALERTE</div>
            <div style={{ color: '#ff2200', fontSize: 18 }}>
              {'█'.repeat(Math.floor(alertLevel / 10))}{'░'.repeat(10 - Math.floor(alertLevel / 10))}
            </div>
          </div>
        )}

        {/* Enemy status */}
        {chasing.length > 0 && (
          <div style={{
            background: 'rgba(120,0,0,0.8)', border: '2px solid #ff0000',
            padding: '6px 14px', borderRadius: 6, textAlign: 'right',
            animation: 'hud-blink 0.5s step-end infinite',
          }}>
            <div style={{ color: '#ff0000', fontSize: 13, letterSpacing: 1 }}>⚠ EN CHASSE</div>
          </div>
        )}

        {/* Status icons */}
        <div style={{ display: 'flex', gap: 8 }}>
          {isCrouching && <StatusIcon label="ACCROUPI" color="#4488ff" icon="▼"/>}
          {isSprinting && <StatusIcon label="SPRINT" color="#ff6600" icon="»"/>}
          {isHiding && <StatusIcon label="CACHÉ" color="#00ff88" icon="◉"/>}
        </div>
      </div>

      {/* CENTER - Cage tutorial or crosshair */}
      {isCage ? (
        <div style={{
          position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -50%)',
          textAlign: 'center', maxWidth: 480,
        }}>
          <div style={{
            background: 'rgba(0,0,0,0.78)', border: '1px solid #334',
            borderRadius: 10, padding: '22px 32px', backdropFilter: 'blur(8px)',
          }}>
            <div style={{ color: '#ff4444', fontSize: 13, letterSpacing: 4, marginBottom: 12 }}>
              CONTRÔLES
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'auto auto', gap: '7px 28px', textAlign: 'left' }}>
              {[
                ['Z / ↑', 'Avancer'],
                ['S / ↓', 'Reculer'],
                ['Souris', 'Regarder'],
                ['Q / ←', 'Tourner'],
                ['D / →', 'Tourner'],
                ['ESPACE', 'Sauter'],
                ['SHIFT', 'Sprinter'],
                ['CTRL', "S'accroupir"],
                ['E', 'Se cacher'],
              ].map(([k, v], i) => (
                <div key={i} style={{ display: 'contents' }}>
                  <span style={{ color: '#ffcc44', fontSize: 12 }}>{k}</span>
                  <span style={{ color: '#aaa', fontSize: 12 }}>{v}</span>
                </div>
              ))}
            </div>
            {!cageDoorOpen ? (
              <div style={{
                marginTop: 18, padding: '8px 16px',
                background: 'rgba(255,80,0,0.12)', borderRadius: 6, border: '1px solid #ff4400',
              }}>
                <div style={{ color: '#ffaa44', fontSize: 10, letterSpacing: 3 }}>PORTE S'OUVRE DANS</div>
                <div style={{ color: '#ff4400', fontSize: 30, fontWeight: 'bold' }}>{Math.ceil(timeLeft)}s</div>
              </div>
            ) : (
              <div style={{
                marginTop: 16, color: '#00ff88', fontSize: 13, letterSpacing: 2,
                animation: 'hud-blink 1s step-end infinite',
              }}>
                ▸ FUYEZ — Trouvez la SORTIE verte
              </div>
            )}
          </div>
        </div>
      ) : (
        <div style={{
          position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -50%)',
          width: 18, height: 18,
        }}>
          <div style={{ position: 'absolute', top: '50%', left: 0, right: 0, height: 1, background: 'rgba(255,255,255,0.45)', transform: 'translateY(-50%)' }}/>
          <div style={{ position: 'absolute', left: '50%', top: 0, bottom: 0, width: 1, background: 'rgba(255,255,255,0.45)', transform: 'translateX(-50%)' }}/>
        </div>
      )}

      {/* Interaction prompt */}
      {nearSpot && !isHiding && (
        <div style={{
          position: 'absolute', left: '50%', bottom: 200, transform: 'translateX(-50%)',
          background: 'rgba(0,0,0,0.8)', border: '1px solid #ffaa00',
          padding: '8px 22px', borderRadius: 6, color: '#ffaa00', fontSize: 13, letterSpacing: 2,
        }}>
          [E] Se cacher — {nearSpot.label}
        </div>
      )}
      {isHiding && (
        <div style={{
          position: 'absolute', left: '50%', bottom: 200, transform: 'translateX(-50%)',
          background: 'rgba(0,15,0,0.85)', border: '1px solid #00ff88',
          padding: '8px 22px', borderRadius: 6, color: '#00ff88', fontSize: 13, letterSpacing: 2,
        }}>
          [E] Sortir de la cachette
        </div>
      )}

      {/* Grace period banner */}
      {gameState === 'playing' && gracePeriod > 0 && (
        <div style={{
          position: 'absolute', left: '50%', top: 55, transform: 'translateX(-50%)',
          background: 'rgba(80,0,120,0.7)', border: '1px solid #8855ff',
          padding: '6px 20px', borderRadius: 6, color: '#bb88ff', fontSize: 11, letterSpacing: 2,
        }}>
          GRÂCE : {Math.ceil(gracePeriod)}s avant que les gardes vous repèrent
        </div>
      )}

      <style>{`
        @keyframes hud-blink {
          0%,100%{opacity:1} 50%{opacity:0}
        }
      `}</style>
    </div>
  );
}

function Bar({ label, value, max, color, icon }: { label:string; value:number; max:number; color:string; icon:string }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', color: '#777', fontSize: 9, letterSpacing: 2, marginBottom: 3 }}>
        <span>{icon} {label}</span>
        <span style={{ color }}>{Math.round(value)}</span>
      </div>
      <div style={{ width: 120, height: 5, background: 'rgba(255,255,255,0.08)', borderRadius: 3, overflow: 'hidden' }}>
        <div style={{ width: `${pct}%`, height: '100%', background: color, borderRadius: 3, transition: 'width 0.1s, background 0.3s', boxShadow: `0 0 5px ${color}` }}/>
      </div>
    </div>
  );
}

function StatusIcon({ label, color, icon }: { label:string; color:string; icon:string }) {
  return (
    <div style={{
      background: 'rgba(0,0,0,0.65)', border: `1px solid ${color}`,
      padding: '4px 10px', borderRadius: 5, color, fontSize: 10, letterSpacing: 2,
    }}>
      {icon} {label}
    </div>
  );
}

function HeartECG({ rate }: { rate: number }) {
  const w = 70, h = 22;
  const period = Math.max(15, (60 / rate) * 70);
  const pts: string[] = [];
  for (let i = 0; i <= w; i++) {
    const t = (i % period) / period;
    let y = h / 2;
    if (t < 0.1) y = h / 2;
    else if (t < 0.15) y = h / 2 - 9 * ((t - 0.1) / 0.05);
    else if (t < 0.2) y = h / 2 + 7 * ((t - 0.15) / 0.05);
    else if (t < 0.25) y = h / 2 - 5 * ((t - 0.2) / 0.05);
    else if (t < 0.3) y = h / 2 + 2 * ((t - 0.25) / 0.05);
    else y = h / 2;
    pts.push(`${i},${y.toFixed(1)}`);
  }
  return (
    <svg width={w} height={h} style={{ display: 'block', marginTop: 4 }}>
      <polyline points={pts.join(' ')} fill="none" stroke="#ff4444" strokeWidth="1.5" opacity="0.85"/>
    </svg>
  );
}
