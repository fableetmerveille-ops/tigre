import { Canvas } from '@react-three/fiber';
import { KeyboardControls } from '@react-three/drei';
import { Suspense } from 'react';
import * as THREE from 'three';
import { useGameStore } from './useGameStore';
import Player from './Player';
import EnemyNPC from './EnemyNPC';
import Office from './Office';
import FirstPersonCamera from './FirstPersonCamera';
import GameLoop from './GameLoop';

const keyMap = [
  { name: 'forward', keys: ['ArrowUp', 'KeyW', 'KeyZ'] },
  { name: 'back', keys: ['ArrowDown', 'KeyS'] },
  { name: 'left', keys: ['ArrowLeft', 'KeyA', 'KeyQ'] },
  { name: 'right', keys: ['ArrowRight', 'KeyD'] },
  { name: 'jump', keys: ['Space'] },
  { name: 'sprint', keys: ['ShiftLeft', 'ShiftRight'] },
  { name: 'crouch', keys: ['ControlLeft', 'ControlRight', 'KeyC'] },
  { name: 'interact', keys: ['KeyE'] },
];

function DynamicFog() {
  const { alertLevel, gracePeriod, isHiding } = useGameStore();
  const far = isHiding ? 8 : gracePeriod > 0 ? 30 : alertLevel > 60 ? 12 : 22;
  return <fog attach="fog" args={['#080810', 2, far]} />;
}

export default function Game3D() {
  const { enemies, gameState, playerPos } = useGameStore();
  const visible = gameState === 'playing' || gameState === 'cage' || gameState === 'caught' || gameState === 'escaped';

  return (
    <div style={{ width: '100vw', height: '100vh', background: '#000', display: visible ? 'block' : 'none' }}>
      <KeyboardControls map={keyMap}>
        <Canvas
          shadows={{ type: THREE.PCFShadowMap }}
          gl={{ antialias: true, toneMapping: THREE.ACESFilmicToneMapping, toneMappingExposure: 0.85 }}
          camera={{
            position: [playerPos[0], playerPos[1] + 0.2, playerPos[2]],
            fov: 82,
            near: 0.04,
            far: 90,
          }}
        >
          <Suspense fallback={null}>
            <DynamicFog />
            <GameLoop />
            <FirstPersonCamera />
            <Office />
            <Player />
            {enemies.map(enemy => (
              <EnemyNPC key={enemy.id} enemy={enemy} />
            ))}
          </Suspense>
        </Canvas>
      </KeyboardControls>
    </div>
  );
}
