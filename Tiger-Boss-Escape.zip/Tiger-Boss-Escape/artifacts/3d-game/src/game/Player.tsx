import { useRef, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { useKeyboardControls } from '@react-three/drei';
import { useGameStore } from './useGameStore';
import { ROOMS, HIDING_SPOTS } from './types';

enum Controls {
  forward = 'forward',
  back = 'back',
  left = 'left',
  right = 'right',
  jump = 'jump',
  sprint = 'sprint',
  crouch = 'crouch',
  interact = 'interact',
}

const GRAVITY = -18;
const JUMP_FORCE = 5.5;
const EYE_NORMAL = 0.18;
const EYE_CROUCH = 0.07;

const SPEED_NORMAL = 3.8;
const SPEED_SPRINT = 6.5;
const SPEED_CROUCH = 1.8;
const TURN_SPEED = 2.0;
const PITCH_LIMIT = Math.PI / 2.5;

const BOUNDS = { minX: -27.5, maxX: 27.5, minZ: -27.5, maxZ: 27.5 };

const OUTER_WALLS = [
  { minX: -30, maxX: -27, minZ: -30, maxZ: 30 },
  { minX: 27, maxX: 30, minZ: -30, maxZ: 30 },
  { minX: -30, maxX: 30, minZ: -30, maxZ: -27 },
  { minX: -30, maxX: 30, minZ: 27, maxZ: 30 },
];

// Inner walls — leaves 10-unit corridor openings at x:[-5,5] and z:[-5,5]
const INNER_WALLS = [
  { minX: -27.5, maxX: -5.5, minZ: -5.5, maxZ: -4.5 },
  { minX: 5.5, maxX: 27.5, minZ: -5.5, maxZ: -4.5 },
  { minX: -27.5, maxX: -5.5, minZ: 4.5, maxZ: 5.5 },
  { minX: 5.5, maxX: 27.5, minZ: 4.5, maxZ: 5.5 },
  { minX: -5.5, maxX: -4.5, minZ: -27.5, maxZ: -5.5 },
  { minX: 4.5, maxX: 5.5, minZ: -27.5, maxZ: -5.5 },
  { minX: -5.5, maxX: -4.5, minZ: 5.5, maxZ: 27.5 },
  { minX: 4.5, maxX: 5.5, minZ: 5.5, maxZ: 27.5 },
];

const CAGE_WALLS = [
  { minX: -20.3, maxX: -9.7, minZ: -20.3, maxZ: -19.7, door: false },
  { minX: -20.3, maxX: -9.7, minZ: -10.3, maxZ: -9.7, door: true },  // south - has door
  { minX: -20.3, maxX: -19.7, minZ: -20.3, maxZ: -9.7, door: false },
  { minX: -10.3, maxX: -9.7, minZ: -20.3, maxZ: -9.7, door: false },
];

function isInWall(x: number, z: number, r = 0.28, doorOpen = false): boolean {
  for (const w of OUTER_WALLS) {
    if (x - r < w.maxX && x + r > w.minX && z - r < w.maxZ && z + r > w.minZ) return true;
  }
  for (const w of INNER_WALLS) {
    if (x - r < w.maxX && x + r > w.minX && z - r < w.maxZ && z + r > w.minZ) return true;
  }
  for (const w of CAGE_WALLS) {
    if (doorOpen && w.door) continue;
    if (x - r < w.maxX && x + r > w.minX && z - r < w.maxZ && z + r > w.minZ) return true;
  }
  return false;
}

function isInCageArea(x: number, z: number) {
  return x > -20.5 && x < -9.5 && z > -20.5 && z < -9.5;
}

const interactCooldown = { t: 0 };

export default function Player() {
  const [, getKeys] = useKeyboardControls<Controls>();
  const posRef = useRef<[number, number, number]>([-15, 0.15, -15]);
  const yawRef = useRef(0);
  const pitchRef = useRef(0);
  const vyRef = useRef(0);
  const groundedRef = useRef(true);
  const cageTimerRef = useRef(0);
  const prevInteract = useRef(false);
  const stepTimer = useRef(0);
  const noiseTimer = useRef(0);
  const leftCage = useRef(false);

  // Reset all refs when game restarts
  useEffect(() => {
    return useGameStore.subscribe((state, prev) => {
      if (prev.gameState !== 'intro' && state.gameState === 'intro') {
        posRef.current = [-15, 0.15, -15];
        yawRef.current = 0;
        pitchRef.current = 0;
        vyRef.current = 0;
        groundedRef.current = true;
        cageTimerRef.current = 0;
        stepTimer.current = 0;
        leftCage.current = false;
        interactCooldown.t = 0;
      }
    });
  }, []);

  // Pointer lock
  useEffect(() => {
    const canvas = document.querySelector('canvas');
    if (!canvas) return;
    let locked = false;

    const onMove = (e: MouseEvent) => {
      if (!locked) return;
      const gs = useGameStore.getState().gameState;
      if (gs !== 'playing' && gs !== 'cage') return;
      yawRef.current -= e.movementX * 0.002;
      pitchRef.current = Math.max(-PITCH_LIMIT, Math.min(PITCH_LIMIT, pitchRef.current - e.movementY * 0.002));
    };
    const onLockChange = () => { locked = document.pointerLockElement === canvas; };
    const onClick = () => {
      const gs = useGameStore.getState().gameState;
      if (gs === 'playing' || gs === 'cage') canvas.requestPointerLock();
    };

    canvas.addEventListener('click', onClick);
    document.addEventListener('mousemove', onMove);
    document.addEventListener('pointerlockchange', onLockChange);
    return () => {
      canvas.removeEventListener('click', onClick);
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('pointerlockchange', onLockChange);
    };
  }, []);

  useFrame((_, delta) => {
    const state = useGameStore.getState();
    const gs = state.gameState;
    if (gs !== 'playing' && gs !== 'cage') return;

    const clampedDelta = Math.min(delta, 0.05); // cap delta to avoid big jumps
    const { forward, back, left, right, jump, sprint: sprintKey, crouch: crouchKey, interact } = getKeys();
    const { cageDoorOpen, isHiding, isCrouching, stamina, gracePeriod, alertLevel, nearHidingSpot } = state;

    // ---- Interaction (E) - hide/unhide ----
    if (interact && !prevInteract.current && interactCooldown.t <= 0) {
      if (nearHidingSpot) {
        const hiding = !isHiding;
        useGameStore.getState().setHiding(hiding, hiding ? nearHidingSpot : null);
        interactCooldown.t = 0.4;
      }
    }
    prevInteract.current = interact;
    interactCooldown.t = Math.max(0, interactCooldown.t - clampedDelta);

    if (isHiding) {
      useGameStore.getState().setNoiseLevel(0);
      // Update camera yaw while hiding
      if (left) yawRef.current += TURN_SPEED * clampedDelta;
      if (right) yawRef.current -= TURN_SPEED * clampedDelta;
      useGameStore.getState().setYaw(yawRef.current);
      useGameStore.getState().setPitch(pitchRef.current);
      return;
    }

    // ---- Camera turn (keyboard) ----
    if (left) yawRef.current += TURN_SPEED * clampedDelta;
    if (right) yawRef.current -= TURN_SPEED * clampedDelta;

    // ---- Crouch / Sprint ----
    const crouching = crouchKey;
    if (crouching !== isCrouching) useGameStore.getState().setCrouching(crouching);

    const canSprint = sprintKey && !crouching && stamina > 5;
    if (canSprint !== state.isSprinting) useGameStore.getState().setSprinting(canSprint);

    // Stamina drain / recover
    const newStamina = canSprint
      ? Math.max(0, stamina - 25 * clampedDelta)
      : Math.min(100, stamina + (crouching ? 15 : 10) * clampedDelta);
    useGameStore.getState().setStamina(newStamina);

    // ---- Movement ----
    const spd = crouching ? SPEED_CROUCH : canSprint ? SPEED_SPRINT : SPEED_NORMAL;
    const [x, , z] = posRef.current;
    let nx = x, nz = z;
    let moving = false;

    if (forward) {
      nx -= Math.sin(yawRef.current) * spd * clampedDelta;
      nz -= Math.cos(yawRef.current) * spd * clampedDelta;
      moving = true;
    }
    if (back) {
      nx += Math.sin(yawRef.current) * spd * clampedDelta;
      nz += Math.cos(yawRef.current) * spd * clampedDelta;
      moving = true;
    }

    nx = Math.max(BOUNDS.minX, Math.min(BOUNDS.maxX, nx));
    nz = Math.max(BOUNDS.minZ, Math.min(BOUNDS.maxZ, nz));

    const wc = (tx: number, tz: number) => isInWall(tx, tz, 0.28, cageDoorOpen);
    if (!wc(nx, nz)) { posRef.current[0] = nx; posRef.current[2] = nz; }
    else if (!wc(nx, z)) { posRef.current[0] = nx; }
    else if (!wc(x, nz)) { posRef.current[2] = nz; }

    // ---- Jump & Gravity ----
    if (jump && groundedRef.current && !crouching) {
      vyRef.current = JUMP_FORCE;
      groundedRef.current = false;
    }
    vyRef.current += GRAVITY * clampedDelta;
    const newY = posRef.current[1] + vyRef.current * clampedDelta;
    if (newY <= 0.15) {
      posRef.current[1] = 0.15;
      vyRef.current = 0;
      groundedRef.current = true;
    } else {
      posRef.current[1] = newY;
    }

    // ---- Step bob ----
    if (moving && groundedRef.current) {
      stepTimer.current += clampedDelta * (canSprint ? 9 : crouching ? 4 : 6);
      useGameStore.getState().setStepPhase(stepTimer.current);
    }

    // ---- Noise ----
    noiseTimer.current += clampedDelta;
    if (noiseTimer.current > 0.05) {
      noiseTimer.current = 0;
      const noise = !moving ? 0 : canSprint ? 90 : crouching ? 15 : 40;
      useGameStore.getState().setNoiseLevel(noise);
    }

    // ---- Sync camera store ----
    const eyeY = crouching ? EYE_CROUCH : EYE_NORMAL;
    const eyePos: [number, number, number] = [posRef.current[0], posRef.current[1] + eyeY, posRef.current[2]];
    useGameStore.getState().setPlayerPos(eyePos);
    useGameStore.getState().setYaw(yawRef.current);
    useGameStore.getState().setPitch(pitchRef.current);

    // ---- Hiding spot proximity ----
    const px = posRef.current[0], pz = posRef.current[2];
    let nearest: string | null = null;
    for (const spot of HIDING_SPOTS) {
      const d = Math.sqrt((px - spot.position[0]) ** 2 + (pz - spot.position[2]) ** 2);
      if (d < spot.radius + 0.9) { nearest = spot.id; break; }
    }
    if (nearest !== state.nearHidingSpot) useGameStore.getState().setNearHidingSpot(nearest);

    // ---- Room detection ----
    for (const room of ROOMS) {
      const b = room.bounds;
      if (px >= b.minX && px <= b.maxX && pz >= b.minZ && pz <= b.maxZ) {
        if (state.currentRoom !== room.name) useGameStore.getState().setCurrentRoom(room.name);
        break;
      }
    }

    // ==== CAGE PHASE ====
    if (gs === 'cage') {
      useGameStore.getState().incrementCageTime(clampedDelta);
      cageTimerRef.current += clampedDelta;
      if (cageTimerRef.current > 45 && !cageDoorOpen) useGameStore.getState().openCageDoor();

      // Transition to PLAYING when player leaves the cage
      if (cageDoorOpen && !isInCageArea(posRef.current[0], posRef.current[2])) {
        useGameStore.getState().setGameState('playing');
      }
      return;
    }

    // ==== PLAYING PHASE ====
    useGameStore.getState().incrementTime(clampedDelta);

    // Grace countdown
    if (gracePeriod > 0) useGameStore.getState().decrementGrace(clampedDelta);

    // Win check
    if (posRef.current[0] > 17 && posRef.current[2] > 22) {
      useGameStore.getState().setGameState('escaped');
    }

    // Heart rate
    const danger = gracePeriod > 0 ? Math.max(0, 10 - gracePeriod * 0.3) : alertLevel;
    const targetHR = 65 + danger * 1.15;
    const hr = state.heartRate;
    useGameStore.getState().setHeartRate(hr + (targetHR - hr) * clampedDelta * 0.6);

    // Alert level passive decay
    const decayRate = isHiding ? 8 : crouching ? 3 : moving ? 0.3 : 1.5;
    const al = useGameStore.getState().alertLevel;
    if (al > 0) useGameStore.getState().setAlertLevel(Math.max(0, al - decayRate * clampedDelta));
  });

  return null;
}
