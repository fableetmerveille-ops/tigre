import { useState, useEffect } from 'react';
import { useGameStore } from './useGameStore';

const STORY_LINES = [
  { text: '07h30 — Siège de NeoCorp Industries', color: '#ff4444', size: 18 },
  { text: 'Vous êtes Richard Moreau, le pdg de cette boite.', color: '#ddd', size: 16 },
  { text: 'PDG de NeoCorp Industries.', color: '#ddd', size: 16 },
  { text: 'Une entreprise de trandfomartion aux activités... douteuses.', color: '#bbb', size: 15 },
  { text: 'Ce matin, vos scientifiques ont préparé une surprise.', color: '#bbb', size: 15 },
  { text: '"Juste quelques gouttes, patron. Ça ne fait pas mal."', color: '#ff8844', size: 15 },
  { text: 'Vous sentez le sol se dérober sous vos pieds.', color: '#aaa', size: 14 },
  { text: 'Votre corps... rétrécit.', color: '#cc4444', size: 16 },
  { text: 'Votre tête... rétrécit.', color: '#cc4444', size: 16 
  { text: 'Vos bras... rétrécissent.', color: '#cc4444', size: 16 },
  { text: 'Des griffes. De la fourrure blanche rayée de noir.', color: '#cc8844', size: 15 },
  { text: 'Vous êtes un tigre.', color: '#ffcc44', size: 16 },
  { text: 'Vous venez d\'être transformé en bébé tigre blanc.', color: '#ffcc44', size: 16 },
  { text: 'Et ils vous ont mis dans une cage.', color: '#ff4444', size: 15 },
  { text: 'Votre propre entreprise. Votre propre bâtiment.', color: '#aaa', size: 13 },
{text: 'il se sont jouer de vous.'}
{text : 'il vous ont transformé en animal'}
{text : 'il vous ont enfermé dans une cage'}
  { text: 'Il faut s\'échapper.', color: '#55ff88', size: 20 },
];

export default function IntroScreen() {
  const { gameState, setGameState, setTransformationProgress } = useGameStore();
  const [lineIndex, setLineIndex] = useState(0);
  const [visible, setVisible] = useState(false);
  const [phase, setPhase] = useState<'story' | 'transform' | 'ready'>('story');
  const [tPct, setTPct] = useState(0);

  useEffect(() => {
    if (gameState !== 'intro') return;
    const t = setTimeout(() => setVisible(true), 400);
    return () => clearTimeout(t);
  }, [gameState]);

  if (gameState !== 'intro' && gameState !== 'transformation') return null;

  const next = () => {
    if (lineIndex < STORY_LINES.length - 1) {
      setVisible(false);
      setTimeout(() => { setLineIndex(l => l + 1); setVisible(true); }, 350);
    } else {
      // Transformation
      setPhase('transform');
      setGameState('transformation');
      let pct = 0;
      const iv = setInterval(() => {
        pct += 1.5;
        setTPct(Math.min(100, pct));
        setTransformationProgress(Math.min(100, pct));
        if (pct >= 100) {
          clearInterval(iv);
          setTimeout(() => setPhase('ready'), 800);
        }
      }, 50);
    }
  };

  const start = () => {
    setGameState('cage');
  };

  const line = STORY_LINES[lineIndex];

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 300,
      background: '#000',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      fontFamily: '"Courier New", monospace',
      cursor: 'default',
    }}>
      {/* Subtle noise overlay */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(ellipse at 50% 40%, rgba(20,20,60,0.6) 0%, #000 80%)',
        pointerEvents: 'none',
      }} />

      {phase === 'story' && (
        <div style={{ maxWidth: 560, textAlign: 'center', padding: '0 32px', position: 'relative', zIndex: 1 }}>
          {/* Company logo */}
          <div style={{
            fontSize: 10, letterSpacing: 5, color: '#cc2222',
            textTransform: 'uppercase', marginBottom: 52,
          }}>
            ◆ NEOCORP INDUSTRIES ◆
          </div>

          {/* Story line */}
          <div style={{
            minHeight: 72,
            opacity: visible ? 1 : 0,
            transition: 'opacity 0.35s ease',
            fontSize: line.size,
            color: line.color,
            lineHeight: 1.6,
            marginBottom: 52,
          }}>
            {line.text}
          </div>

          {/* Progress dots */}
          <div style={{ display: 'flex', gap: 6, justifyContent: 'center', marginBottom: 36 }}>
            {STORY_LINES.map((_, i) => (
              <div key={i} style={{
                width: 6, height: 6, borderRadius: '50%',
                background: i === lineIndex ? '#fff' : i < lineIndex ? '#555' : '#222',
                transition: 'background 0.3s',
              }} />
            ))}
          </div>

          <button
            onClick={next}
            style={{
              background: 'none', border: '1px solid #333', color: '#888',
              padding: '11px 32px', cursor: 'pointer', fontSize: 12,
              letterSpacing: 3, textTransform: 'uppercase', transition: 'all 0.2s',
            }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = '#666'; e.currentTarget.style.color = '#ccc'; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = '#333'; e.currentTarget.style.color = '#888'; }}
          >
            {lineIndex < STORY_LINES.length - 1 ? 'Suite →' : 'La transformation commence...'}
          </button>
        </div>
      )}

      {(phase === 'transform' || phase === 'ready') && (
        <div style={{ maxWidth: 480, textAlign: 'center', padding: '0 32px', position: 'relative', zIndex: 1 }}>
          <div style={{ fontSize: 12, color: '#ff6600', letterSpacing: 3, marginBottom: 36, textTransform: 'uppercase' }}>
            {tPct < 100 ? 'Transformation en cours...' : 'Transformation complète'}
          </div>

          {/* Tiger silhouette animation */}
          <div style={{ position: 'relative', width: 140, height: 140, margin: '0 auto 36px' }}>
            {/* Outer glow */}
            <div style={{
              position: 'absolute', inset: 0, borderRadius: '50%',
              background: `radial-gradient(circle, rgba(255,255,255,${tPct / 200}) 0%, transparent 70%)`,
              boxShadow: `0 0 ${tPct * 0.6}px rgba(255,255,255,${tPct / 300})`,
              transition: 'all 0.1s',
            }} />
            {/* Tiger body */}
            <div style={{
              position: 'absolute', top: '35%', left: '20%',
              width: '60%', height: '35%',
              background: `rgba(240,240,240,${tPct / 130})`,
              borderRadius: '50%',
              boxShadow: tPct > 50 ? '0 0 12px rgba(255,255,255,0.4)' : 'none',
            }} />
            {/* Tiger head */}
            <div style={{
              position: 'absolute', top: '22%', left: '32%',
              width: '36%', height: '30%',
              background: `rgba(240,240,240,${tPct / 130})`,
              borderRadius: '50%',
            }} />
            {/* Eyes */}
            {tPct > 60 && (
              <>
                <div style={{
                  position: 'absolute', top: '28%', left: '35%',
                  width: 10, height: 10, borderRadius: '50%',
                  background: '#1a9fff',
                  boxShadow: '0 0 8px #1a9fff',
                  opacity: (tPct - 60) / 40,
                }} />
                <div style={{
                  position: 'absolute', top: '28%', left: '53%',
                  width: 10, height: 10, borderRadius: '50%',
                  background: '#1a9fff',
                  boxShadow: '0 0 8px #1a9fff',
                  opacity: (tPct - 60) / 40,
                }} />
              </>
            )}
            {/* Stripes */}
            {tPct > 70 && [30, 45, 60].map(t => (
              <div key={t} style={{
                position: 'absolute', top: `${t}%`, left: '18%',
                width: '64%', height: 3,
                background: 'rgba(30,30,30,0.6)',
                borderRadius: 2,
                opacity: (tPct - 70) / 30,
              }} />
            ))}
          </div>

          {/* Progress bar */}
          <div style={{ height: 6, background: '#1a1a1a', borderRadius: 3, width: 280, margin: '0 auto 12px', overflow: 'hidden' }}>
            <div style={{
              height: '100%', width: `${tPct}%`,
              background: 'linear-gradient(90deg, #ff6600, #ffeecc)',
              transition: 'width 0.08s',
            }} />
          </div>
          <div style={{ color: '#666', fontSize: 12 }}>{Math.round(tPct)}%</div>

          {phase === 'ready' && (
            <div style={{ marginTop: 40 }}>
              <div style={{ color: '#ffcc44', fontSize: 17, marginBottom: 10 }}>
                Vous êtes un bébé tigre blanc.
              </div>
              <div style={{ color: '#888', fontSize: 13, marginBottom: 8, lineHeight: 1.8 }}>
                Vous vous réveillez dans la cage du laboratoire.<br />
                Prenez le temps de vous repérer.<br />
                La cage s'ouvrira bientôt.
              </div>
              <div style={{ color: '#555', fontSize: 12, marginBottom: 32 }}>
                Objectif : rejoindre la <span style={{ color: '#55ff88' }}>sortie verte</span> du bâtiment.
              </div>
              <button
                onClick={start}
                style={{
                  background: 'rgba(0,150,60,0.15)', border: '1px solid #00aa44',
                  color: '#00ff66', padding: '14px 44px', cursor: 'pointer',
                  fontSize: 14, letterSpacing: 3, textTransform: 'uppercase',
                  transition: 'all 0.2s',
                }}
                onMouseEnter={e => {
                  e.currentTarget.style.background = 'rgba(0,180,70,0.25)';
                  e.currentTarget.style.boxShadow = '0 0 18px rgba(0,255,80,0.25)';
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.background = 'rgba(0,150,60,0.15)';
                  e.currentTarget.style.boxShadow = 'none';
                }}
              >
                Je suis prêt — entrer dans la cage
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
