import { useGameStore } from './useGameStore';

export default function PawsOverlay() {
  const { stepPhase, isCrouching, isSprinting, isHiding, gameState } = useGameStore();
  if (gameState !== 'playing' && gameState !== 'cage') return null;

  // Bob based on step phase
  const bob = Math.sin(stepPhase) * (isSprinting ? 18 : isCrouching ? 5 : 10);
  const bobR = Math.cos(stepPhase) * 8;
  const hide = isHiding;

  return (
    <div style={{
      position: 'fixed',
      bottom: 0,
      left: 0,
      right: 0,
      height: 180,
      pointerEvents: 'none',
      zIndex: 10,
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      padding: '0 40px',
      opacity: hide ? 0.3 : 1,
      transition: 'opacity 0.4s',
    }}>
      {/* Left Paw */}
      <div style={{
        transform: `translateY(${-bob * 0.5 + 30}px) rotate(${-bobR + 15}deg)`,
        transition: 'transform 0.05s',
      }}>
        <Paw mirrored={false} />
      </div>

      {/* Right Paw */}
      <div style={{
        transform: `translateY(${bob * 0.5 + 30}px) rotate(${bobR - 15}deg)`,
        transition: 'transform 0.05s',
      }}>
        <Paw mirrored={true} />
      </div>
    </div>
  );
}

function Paw({ mirrored }: { mirrored: boolean }) {
  const { health } = useGameStore();
  const bloody = health < 50;

  return (
    <svg
      width="130"
      height="140"
      viewBox="0 0 130 140"
      style={{ transform: mirrored ? 'scaleX(-1)' : 'none', filter: 'drop-shadow(0 8px 18px rgba(0,0,0,0.7))' }}
    >
      {/* Main paw pad */}
      <ellipse cx="65" cy="105" rx="42" ry="32" fill="#f5f0e8" />
      {/* Paw central pad */}
      <ellipse cx="65" cy="112" rx="24" ry="18" fill="#d4bfaf" />
      {/* Toe pads */}
      <ellipse cx="36" cy="88" rx="13" ry="10" fill="#f5f0e8" />
      <ellipse cx="55" cy="78" rx="13" ry="10" fill="#f5f0e8" />
      <ellipse cx="75" cy="78" rx="13" ry="10" fill="#f5f0e8" />
      <ellipse cx="94" cy="88" rx="13" ry="10" fill="#f5f0e8" />
      {/* Toe inner pads */}
      <ellipse cx="36" cy="90" rx="7" ry="6" fill="#d4bfaf" />
      <ellipse cx="55" cy="80" rx="7" ry="6" fill="#d4bfaf" />
      <ellipse cx="75" cy="80" rx="7" ry="6" fill="#d4bfaf" />
      <ellipse cx="94" cy="90" rx="7" ry="6" fill="#d4bfaf" />
      {/* Claws */}
      <path d="M32 82 Q28 70 30 62" stroke="#ccc" strokeWidth="3" fill="none" strokeLinecap="round"/>
      <path d="M51 72 Q50 60 53 52" stroke="#ccc" strokeWidth="3" fill="none" strokeLinecap="round"/>
      <path d="M71 72 Q73 60 71 52" stroke="#ccc" strokeWidth="3" fill="none" strokeLinecap="round"/>
      <path d="M90 82 Q94 70 93 62" stroke="#ccc" strokeWidth="3" fill="none" strokeLinecap="round"/>
      {/* Tiger stripes */}
      <path d="M50 100 Q65 96 80 100" stroke="#999" strokeWidth="2" fill="none" opacity="0.4"/>
      <path d="M52 107 Q65 104 78 107" stroke="#999" strokeWidth="1.5" fill="none" opacity="0.3"/>
      {/* Blood if low health */}
      {bloody && <>
        <ellipse cx="55" cy="115" rx="5" ry="3" fill="#cc0000" opacity="0.7"/>
        <path d="M62 110 Q60 118 58 122" stroke="#cc0000" strokeWidth="2" fill="none" opacity="0.6"/>
      </>}
      {/* Outline */}
      <ellipse cx="65" cy="105" rx="42" ry="32" fill="none" stroke="#bba" strokeWidth="1.5" opacity="0.5"/>
    </svg>
  );
}
