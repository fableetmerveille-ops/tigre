import React, { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useGameStore } from './useGameStore';
import { Enemy } from './types';

const CATCH_RADIUS = 0.85;
const SIGHT_RANGE_NORMAL = 7;
const SIGHT_RANGE_ALERT = 12;
const NOISE_HEAR_RANGE = 9;
const NOISE_HEAR_RANGE_GUARD = 13;
const SEARCH_DURATION = 8;

const PATROL_ROUTES: Record<string, Array<[number, number]>> = {
  scientist1: [[-18, -8], [-9, -15], [-18, -22], [-9, -22]],
  scientist2: [[-10, -18], [-15, -8], [-22, -15], [-15, -22]],
  scientist3: [[18, -22], [26, -22], [26, -8], [18, -8]],
  scientist4: [[0, -22], [4, -22], [4, -8], [0, -8]],
  guard1: [[0, -1], [4, -3], [0, 3], [-4, -3], [0, 0]],
  guard2: [[18, 18], [26, 18], [26, 26], [18, 26]],
  employee1: [[-18, 18], [-8, 18], [-8, 26], [-18, 26]],
  employee2: [[8, 18], [14, 18], [14, 26], [8, 26]],
};

const COLORS = {
  scientist: { body: '#2255bb', coat: '#e8e8e8', skin: '#f5c89a' },
  guard: { body: '#1a1a1a', coat: '#222', skin: '#cc9977' },
  employee: { body: '#336622', coat: '', skin: '#f0c090' },
};

interface Props { enemy: Enemy }

export default function EnemyNPC({ enemy }: Props) {
  const gRef = useRef<THREE.Group>(null);
  const [pIdx, setPIdx] = useState(0);
  const posRef = useRef({ x: enemy.position[0], z: enemy.position[2] });
  const rotRef = useRef(0);
  const bobRef = useRef(Math.random() * Math.PI * 2);
  const searchPosRef = useRef<[number, number] | null>(null);

  useFrame((_, delta) => {
    const gs = useGameStore.getState().gameState;
    if (gs !== 'playing' && gs !== 'cage') return;

    const { playerPos, isHiding, noiseLevel, alertLevel, gracePeriod, damagePlayer, updateEnemy } = useGameStore.getState();
    const px = playerPos[0], pz = playerPos[2];
    const ex = posRef.current.x, ez = posRef.current.z;
    const distToPlayer = Math.sqrt((px - ex) ** 2 + (pz - ez) ** 2);

    const canAttack = gs === 'playing' && gracePeriod <= 0;
    const isCageObserver = enemy.id === 'scientist1' || enemy.id === 'scientist2';

    let targetX = ex, targetZ = ez;
    let spd = enemy.speed;
    let newAIState = enemy.aiState;
    let newSearchTimer = enemy.searchTimer;
    let newLastKnown = enemy.lastKnownPlayerPos;

    bobRef.current += delta * 5;

    // --- CAGE PHASE: just patrol/observe ---
    if (gs === 'cage' || !canAttack) {
      const route = PATROL_ROUTES[enemy.id] ?? [];
      if (route.length > 0) {
        const [tx, tz] = route[pIdx % route.length];
        targetX = tx; targetZ = tz;
        const pd = Math.sqrt((tx - ex) ** 2 + (tz - ez) ** 2);
        if (pd < 0.4) setPIdx(i => (i + 1) % route.length);
        spd = isCageObserver ? 1.0 : enemy.speed * 0.5;
      }
      moveTowards(posRef, rotRef, targetX, targetZ, spd, delta);
      if (gRef.current) {
        gRef.current.position.set(posRef.current.x, 0, posRef.current.z);
        gRef.current.rotation.y = rotRef.current;
        gRef.current.position.y = Math.abs(Math.sin(bobRef.current)) * 0.02;
      }
      return;
    }

    // --- AI STATE MACHINE ---
    const sightRange = enemy.aiState !== 'patrol' ? SIGHT_RANGE_ALERT : SIGHT_RANGE_NORMAL;
    const hearRange = enemy.type === 'guard' ? NOISE_HEAR_RANGE_GUARD : NOISE_HEAR_RANGE;
    const playerHidden = isHiding;
    const loudEnough = noiseLevel > 20 && distToPlayer < hearRange;

    switch (enemy.aiState) {
      case 'patrol': {
        const route = PATROL_ROUTES[enemy.id] ?? [];
        if (route.length > 0) {
          const [tx, tz] = route[pIdx % route.length];
          targetX = tx; targetZ = tz;
          const pd = Math.sqrt((tx - ex) ** 2 + (tz - ez) ** 2);
          if (pd < 0.4) setPIdx(i => (i + 1) % route.length);
        }
        if (!playerHidden && distToPlayer < sightRange) {
          newAIState = 'alert';
          useGameStore.getState().setAlertLevel(Math.min(100, alertLevel + 25));
        } else if (loudEnough) {
          newAIState = 'alert';
          newLastKnown = [px, pz];
          useGameStore.getState().setAlertLevel(Math.min(100, alertLevel + 10));
        }
        break;
      }
      case 'alert': {
        if (!playerHidden && distToPlayer < sightRange) {
          newAIState = 'chase';
          newLastKnown = [px, pz];
          useGameStore.getState().setAlertLevel(Math.min(100, alertLevel + 30));
        } else if (loudEnough) {
          targetX = px; targetZ = pz;
          newLastKnown = [px, pz];
        } else {
          newSearchTimer += delta;
          if (newSearchTimer > 3) { newAIState = 'patrol'; newSearchTimer = 0; }
        }
        break;
      }
      case 'chase': {
        if (playerHidden && distToPlayer > 2) {
          newAIState = 'search';
          newSearchTimer = 0;
          searchPosRef.current = newLastKnown ?? [px, pz];
        } else if (!playerHidden && distToPlayer < sightRange) {
          targetX = px; targetZ = pz;
          newLastKnown = [px, pz];
          spd = enemy.speed * 1.2;
          if (distToPlayer < CATCH_RADIUS) {
            damagePlayer(enemy.type === 'guard' ? 28 : 14);
            useGameStore.getState().setAlertLevel(Math.min(100, alertLevel + 30));
          }
        } else {
          newAIState = 'search';
          newSearchTimer = 0;
        }
        break;
      }
      case 'search': {
        const sp = searchPosRef.current ?? newLastKnown;
        if (sp) { targetX = sp[0]; targetZ = sp[1]; }
        newSearchTimer += delta;
        if (!playerHidden && distToPlayer < sightRange) {
          newAIState = 'chase';
          newLastKnown = [px, pz];
        }
        if (newSearchTimer > SEARCH_DURATION) {
          newAIState = 'patrol';
          newSearchTimer = 0;
          searchPosRef.current = null;
        }
        break;
      }
    }

    if (newAIState !== enemy.aiState || newSearchTimer !== enemy.searchTimer || newLastKnown !== enemy.lastKnownPlayerPos) {
      updateEnemy(enemy.id, {
        aiState: newAIState,
        isAlerted: newAIState !== 'patrol',
        searchTimer: newSearchTimer,
        lastKnownPlayerPos: newLastKnown,
      });
    }

    if (enemy.aiState === 'chase') targetX = px, targetZ = pz;
    moveTowards(posRef, rotRef, targetX, targetZ, spd, delta);

    if (gRef.current) {
      gRef.current.position.set(posRef.current.x, 0, posRef.current.z);
      gRef.current.rotation.y = rotRef.current;
      const moving = Math.sqrt((targetX - posRef.current.x) ** 2 + (targetZ - posRef.current.z) ** 2) > 0.1;
      gRef.current.position.y = moving ? Math.abs(Math.sin(bobRef.current)) * 0.03 : 0;
    }
  });

  const c = COLORS[enemy.type];
  const isGuard = enemy.type === 'guard';
  const isAlerted = enemy.aiState === 'chase' || enemy.aiState === 'alert';

  return (
    <group ref={gRef} position={[enemy.position[0], 0, enemy.position[2]]}>
      {/* Torso */}
      <mesh castShadow position={[0, 0.95, 0]}>
        <boxGeometry args={isGuard ? [0.62, 1.2, 0.42] : [0.52, 1.05, 0.36]} />
        <meshStandardMaterial color={c.body} roughness={0.7} />
      </mesh>
      {/* Lab coat */}
      {enemy.type === 'scientist' && (
        <mesh position={[0, 0.95, 0.19]}>
          <boxGeometry args={[0.54, 1.07, 0.02]} />
          <meshStandardMaterial color={c.coat} roughness={0.9} />
        </mesh>
      )}
      {/* Head */}
      <mesh castShadow position={[0, 1.72, 0]}>
        <boxGeometry args={[0.4, 0.42, 0.4]} />
        <meshStandardMaterial color={c.skin} roughness={0.9} />
      </mesh>
      {/* Hair */}
      <mesh position={[0, 1.95, 0]}>
        <boxGeometry args={[0.41, 0.1, 0.41]} />
        <meshStandardMaterial color={isGuard ? '#111' : '#3a2200'} roughness={1} />
      </mesh>
      {/* Eyes */}
      <mesh position={[-0.1, 1.77, 0.21]}>
        <sphereGeometry args={[0.045, 6, 6]} />
        <meshStandardMaterial color={isAlerted ? '#ff0000' : '#111'} emissive={isAlerted ? '#ff0000' : '#000'} emissiveIntensity={isAlerted ? 0.8 : 0} />
      </mesh>
      <mesh position={[0.1, 1.77, 0.21]}>
        <sphereGeometry args={[0.045, 6, 6]} />
        <meshStandardMaterial color={isAlerted ? '#ff0000' : '#111'} emissive={isAlerted ? '#ff0000' : '#000'} emissiveIntensity={isAlerted ? 0.8 : 0} />
      </mesh>
      {/* Mouth (grim when alerted) */}
      <mesh position={[0, 1.65, 0.21]}>
        <boxGeometry args={[0.12, 0.025, 0.01]} />
        <meshStandardMaterial color={isAlerted ? '#cc0000' : '#666'} />
      </mesh>
      {/* Legs */}
      <mesh position={[-0.14, 0.27, 0]} castShadow>
        <boxGeometry args={[0.18, 0.54, 0.24]} />
        <meshStandardMaterial color={c.body} roughness={0.7} />
      </mesh>
      <mesh position={[0.14, 0.27, 0]} castShadow>
        <boxGeometry args={[0.18, 0.54, 0.24]} />
        <meshStandardMaterial color={c.body} roughness={0.7} />
      </mesh>
      {/* Arms */}
      <mesh position={[-0.42, 0.95, 0]} castShadow>
        <boxGeometry args={[0.15, 0.7, 0.2]} />
        <meshStandardMaterial color={enemy.type === 'scientist' ? '#e8e8e8' : c.body} roughness={0.7} />
      </mesh>
      <mesh position={[0.42, 0.95, 0]} castShadow>
        <boxGeometry args={[0.15, 0.7, 0.2]} />
        <meshStandardMaterial color={enemy.type === 'scientist' ? '#e8e8e8' : c.body} roughness={0.7} />
      </mesh>
      {/* Guard cap */}
      {isGuard && (
        <>
          <mesh position={[0, 2.0, 0]}>
            <boxGeometry args={[0.5, 0.14, 0.5]} />
            <meshStandardMaterial color="#111" />
          </mesh>
          <mesh position={[0, 2.08, 0.28]}>
            <boxGeometry args={[0.5, 0.04, 0.12]} />
            <meshStandardMaterial color="#111" />
          </mesh>
        </>
      )}
      {/* Glasses (scientists) */}
      {enemy.type === 'scientist' && (
        <>
          <mesh position={[-0.1, 1.78, 0.21]}>
            <torusGeometry args={[0.07, 0.01, 4, 8]} rotation={[Math.PI / 2, 0, 0]} />
            <meshStandardMaterial color="#222" metalness={0.8} />
          </mesh>
          <mesh position={[0.1, 1.78, 0.21]}>
            <torusGeometry args={[0.07, 0.01, 4, 8]} rotation={[Math.PI / 2, 0, 0]} />
            <meshStandardMaterial color="#222" metalness={0.8} />
          </mesh>
        </>
      )}
      {/* Alert exclamation mark */}
      {isAlerted && enemy.aiState === 'chase' && (
        <group position={[0, 2.4, 0]}>
          <mesh>
            <sphereGeometry args={[0.15, 8, 8]} />
            <meshStandardMaterial color="#ff0000" emissive="#ff2200" emissiveIntensity={2} />
          </mesh>
          <pointLight color="#ff2200" intensity={4} distance={5} />
        </group>
      )}
      {/* Question mark when searching */}
      {enemy.aiState === 'search' && (
        <mesh position={[0, 2.35, 0]}>
          <sphereGeometry args={[0.1, 6, 6]} />
          <meshStandardMaterial color="#ffaa00" emissive="#ffaa00" emissiveIntensity={1.5} />
        </mesh>
      )}
    </group>
  );
}

function moveTowards(
  posRef: React.MutableRefObject<{ x: number; z: number }>,
  rotRef: React.MutableRefObject<number>,
  tx: number, tz: number,
  speed: number, delta: number
) {
  const dx = tx - posRef.current.x;
  const dz = tz - posRef.current.z;
  const d = Math.sqrt(dx * dx + dz * dz);
  if (d > 0.05) {
    posRef.current.x += (dx / d) * speed * delta;
    posRef.current.z += (dz / d) * speed * delta;
    rotRef.current = Math.atan2(dx / d, dz / d);
  }
}
