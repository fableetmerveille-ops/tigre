import { useFrame, useThree } from '@react-three/fiber';
import { useGameStore } from './useGameStore';

export default function FirstPersonCamera() {
  const { camera } = useThree();

  useFrame(() => {
    const { playerPos, yaw, pitch, gameState, isCrouching, isHiding } = useGameStore.getState();
    if (gameState !== 'playing' && gameState !== 'cage') return;

    const eyeY = playerPos[1] + (isCrouching ? -0.04 : 0.06) + (isHiding ? -0.08 : 0);

    camera.position.set(playerPos[0], eyeY, playerPos[2]);
    camera.rotation.order = 'YXZ';
    camera.rotation.y = yaw;
    camera.rotation.x = pitch;
  });

  return null;
}
