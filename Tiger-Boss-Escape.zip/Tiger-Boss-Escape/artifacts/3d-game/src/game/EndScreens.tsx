import { useGameStore } from './useGameStore';

export default function EndScreens() {
  const { gameState, resetGame, timeElapsed } = useGameStore();

  if (gameState !== 'caught' && gameState !== 'escaped') return null;

  const minutes = Math.floor(timeElapsed / 60);
  const seconds = Math.floor(timeElapsed % 60);
  const timeStr = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const isCaught = gameState === 'caught';

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 200,
      background: isCaught
        ? 'radial-gradient(ellipse at center, #1a0000 0%, #000 100%)'
        : 'radial-gradient(ellipse at center, #001a0a 0%, #000 100%)',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      fontFamily: '"Courier New", monospace',
      color: '#fff',
    }}>
      {isCaught ? (
        <>
          <div style={{ fontSize: 60, marginBottom: 16 }}>💀</div>
          <div style={{
            fontSize: 32, fontWeight: 'bold', color: '#cc2222',
            textShadow: '0 0 30px rgba(200,0,0,0.6)', marginBottom: 12,
          }}>
            CAPTURÉ
          </div>
          <div style={{ color: '#888', fontSize: 15, marginBottom: 8 }}>
            Vos scientifiques vous ont rattrapé.
          </div>
          <div style={{ color: '#555', fontSize: 13, marginBottom: 32 }}>
            Temps de survie : {timeStr}
          </div>
          <div style={{ color: '#666', fontSize: 12, marginBottom: 32, textAlign: 'center', maxWidth: 360 }}>
            Ils vous remettront dans leur cage dorée.<br />
            Leur prochain sujet d'expérience... ou leur mascotte.
          </div>
        </>
      ) : (
        <>
          <div style={{ fontSize: 60, marginBottom: 16 }}>🐯</div>
          <div style={{
            fontSize: 32, fontWeight: 'bold', color: '#00cc66',
            textShadow: '0 0 30px rgba(0,200,100,0.6)', marginBottom: 12,
          }}>
            VOUS AVEZ FUIT !
          </div>
          <div style={{ color: '#aaa', fontSize: 15, marginBottom: 8 }}>
            Le bébé tigre blanc est libre.
          </div>
          <div style={{ color: '#555', fontSize: 13, marginBottom: 32 }}>
            Temps d'évasion : {timeStr}
          </div>
          <div style={{ color: '#666', fontSize: 12, marginBottom: 32, textAlign: 'center', maxWidth: 360 }}>
            NeoCorp Industries sera bientôt au courant.<br />
            Mais vous, vous êtes libre. Pour l'instant.
          </div>
        </>
      )}

      <button
        onClick={resetGame}
        style={{
          background: 'none',
          border: `1px solid ${isCaught ? '#882222' : '#226644'}`,
          color: isCaught ? '#cc4444' : '#44cc88',
          padding: '12px 32px', cursor: 'pointer',
          fontSize: 14, letterSpacing: 3, textTransform: 'uppercase',
          transition: 'all 0.2s',
        }}
        onMouseEnter={e => {
          e.currentTarget.style.background = isCaught ? 'rgba(180,0,0,0.15)' : 'rgba(0,180,80,0.15)';
        }}
        onMouseLeave={e => {
          e.currentTarget.style.background = 'none';
        }}
      >
        Rejouer
      </button>
    </div>
  );
}
