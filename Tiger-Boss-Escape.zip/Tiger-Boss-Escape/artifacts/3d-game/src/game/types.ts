export type GameState = 'intro' | 'transformation' | 'cage' | 'playing' | 'caught' | 'escaped';
export type EnemyAIState = 'patrol' | 'alert' | 'search' | 'chase';

export interface Enemy {
  id: string;
  position: [number, number, number];
  type: 'scientist' | 'guard' | 'employee';
  speed: number;
  isAlerted: boolean;
  aiState: EnemyAIState;
  lastKnownPlayerPos: [number, number] | null;
  searchTimer: number;
  alertLevel: number;
}

export interface HidingSpot {
  id: string;
  position: [number, number, number]; // center
  radius: number;
  label: string;
}

export interface Room {
  id: string;
  name: string;
  bounds: { minX: number; maxX: number; minZ: number; maxZ: number };
}

export const CAGE_CENTER = { x: -15, z: -15 };
export const CAGE_SIZE = 5;

// Hiding spots around the building
export const HIDING_SPOTS: HidingSpot[] = [
  { id: 'locker1', position: [-26, 0, -22], radius: 1.5, label: 'Armoire' },
  { id: 'locker2', position: [-26, 0, -8], radius: 1.5, label: 'Armoire' },
  { id: 'desk1', position: [11, 0, -22], radius: 1.2, label: 'Sous le bureau' },
  { id: 'desk2', position: [22, 0, -12], radius: 1.2, label: 'Sous le bureau' },
  { id: 'boxes1', position: [-22, 0, 22], radius: 2.0, label: 'Derrière les caisses' },
  { id: 'boxes2', position: [-12, 0, 14], radius: 1.5, label: 'Derrière les caisses' },
  { id: 'corner1', position: [26, 0, -26], radius: 1.2, label: 'Coin sombre' },
  { id: 'vent', position: [0, 0, -26], radius: 1.0, label: 'Bouche d\'aération' },
];

export const ROOMS: Room[] = [
  { id: 'cage', name: 'Cage Labo', bounds: { minX: -20, maxX: -10, minZ: -20, maxZ: -10 } },
  { id: 'lab', name: 'Laboratoire', bounds: { minX: -28, maxX: -5, minZ: -28, maxZ: -5 } },
  { id: 'corridor_n', name: 'Couloir Nord', bounds: { minX: -5, maxX: 5, minZ: -28, maxZ: -5 } },
  { id: 'office', name: 'Bureaux', bounds: { minX: 5, maxX: 28, minZ: -28, maxZ: -5 } },
  { id: 'hallway', name: 'Hall Central', bounds: { minX: -15, maxX: 15, minZ: -5, maxZ: 5 } },
  { id: 'corridor_s', name: 'Couloir Sud', bounds: { minX: -5, maxX: 5, minZ: 5, maxZ: 28 } },
  { id: 'storage', name: 'Entrepôt', bounds: { minX: -28, maxX: -5, minZ: 5, maxZ: 28 } },
  { id: 'lobby', name: '★ SORTIE ★', bounds: { minX: 5, maxX: 28, minZ: 5, maxZ: 28 } },
];
