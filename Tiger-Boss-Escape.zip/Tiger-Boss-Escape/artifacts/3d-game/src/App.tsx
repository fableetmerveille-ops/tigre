import IntroScreen from './game/IntroScreen';
import Game3D from './game/Game3D';
import HUD from './game/HUD';
import EndScreens from './game/EndScreens';
import PawsOverlay from './game/PawsOverlay';
import HorrorEffects from './game/HorrorEffects';

export default function App() {
  return (
    <div style={{ width: '100vw', height: '100vh', overflow: 'hidden', background: '#000' }}>
      <style>{`
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { overflow: hidden; background: #000; }
        canvas { display: block; }
      `}</style>
      <IntroScreen />
      <Game3D />
      <HorrorEffects />
      <PawsOverlay />
      <HUD />
      <EndScreens />
    </div>
  );
}
